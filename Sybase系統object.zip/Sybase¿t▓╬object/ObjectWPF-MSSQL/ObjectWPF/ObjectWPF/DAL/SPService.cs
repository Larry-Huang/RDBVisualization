﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObjectWPF.Model;

namespace ObjectWPF.DAL
{
    public class SPService
    {
        public static List<StoreProcedurees> GetSPDetial(string id)
        {
            string sql = string.Format(@"select DISTINCT schema_name(obj.schema_id) as schema_name,
                       obj.name as procedure_name,
                       schema_name(dep_obj.schema_id) as referenced_object_schema,
                       dep_obj.name as referenced_object_name,
                       dep_obj.type_desc as object_type
                from sys.objects obj
                left join sys.sql_expression_dependencies dep
                          on dep.referencing_id = obj.object_id
                left join sys.objects dep_obj
                          on dep_obj.object_id = dep.referenced_id
                where obj.type in ('P', 'X', 'PC', 'RF')
                    and obj.name = '{0}'  
                order by schema_name,
                         procedure_name;", id);
            
            try
            {
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text);
                List<StoreProcedurees> tbs = new List<StoreProcedurees>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    StoreProcedurees sp = new StoreProcedurees();
                    sp.項次 = i + 1;
                    sp.關聯物件名稱 = dt.Rows[i]["referenced_object_name"].ToString();
                    sp.類別 = dt.Rows[i]["object_type"].ToString();
                    string sql2 = string.Format(@"  select  distinct o.name, o.type_desc, dep.is_updated
                    FROM sys.sql_modules   m 
                    INNER JOIN sys.objects o ON m.object_id=o.object_id
                    INNER JOIN sys.sql_dependencies dep ON m.object_id = dep.object_id
                    INNER JOIN sys.columns col ON dep.referenced_major_id = col.object_id
                    INNER JOIN sys.tables tab ON tab.object_id = col.object_id
                    WHERE tab.name = '{0}' and o.name='{1}'
                    ORDER BY O.name", sp.關聯物件名稱 , id);
                    var dtresultt = SQLhelp.SelectSqlReturnDataTable(sql2, CommandType.Text);
                    if (dtresultt.Rows.Count > 0)
                    {
                        if (dtresultt.Rows.Count == 2)
                        {
                            sp.異動權限 = "SELECTED & MODIFIED";
                        }
                        else
                        {
                            var check = dtresultt.Rows[0][2].ToString();
                            sp.異動權限 = check == "True" ? "MODIFIED" : "SELECTED";
                        }
                    }
                    tbs.Add(sp);
                }
                if (tbs.Count == 0)
                {
                    tbs.Add(new StoreProcedurees
                    {
                        關聯物件名稱 = "查無資料"
                    }
                        );
                }
                return tbs;
            }
            catch (Exception)
            {
                
                throw;
            }
        }

    }
}
