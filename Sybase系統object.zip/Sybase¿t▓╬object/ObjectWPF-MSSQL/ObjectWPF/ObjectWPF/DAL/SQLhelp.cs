﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObjectWPF.Model;

namespace ObjectWPF.DAL
{
    public class SQLhelp
    {

        public static string conn;
        public static string _dbName;

        private static string connString;

        public static string ConnString
        {
            get
            {
                //    get { return @"Dsn=SE_X19D;uid=mfdbo;pwd=mfo861"; }
                return conn;
            }
            set { connString = value; }

        }


        #region ExcuteSQLReturnInt 執行sql回傳受影響的行數
        /// <summary>
        /// 執行sql回傳受影響的行數(int)ExcuteSQLReturnInt
        /// </summary>
        /// <param name="sql">insert,update,delete或預存程序</param>
        /// <param name="type">命令類型</param>
        /// <param name="pars">參數</param>
        /// <returns>int</returns>
        public static int ExcuteSQLReturnInt(string sql, CommandType type, SqlParameter[] pars)
        {
            //定義連接對象
            SqlConnection conn = new SqlConnection(ConnString);
            //打開連接
            if (conn.State == ConnectionState.Closed || conn.State == ConnectionState.Broken)
            {
                conn.Open();
            }
            try
            {
                //執行sql命令
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = type;
                if (pars != null && pars.Length > 0)
                {
                    foreach (SqlParameter p in pars)
                    {
                        cmd.Parameters.Add(p);
                    }
                }

                //執行
                int count = cmd.ExecuteNonQuery();
                return count;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
        } 
        #endregion


        #region 執行一個sql語句，回傳一個紀錄SqlDataReader
        /// <summary>
        /// 執行一個sql語句，回傳一個紀錄SqlDataReader
        /// </summary>
        /// <param name="sql">select * from where id=......或相關的預存程序</param>
        /// <param name="type">指定的命令類型</param>
        /// <param name="pars">參數集合</param>
        /// <returns>reader</returns>
        public static SqlDataReader ExcuteSqlReturnReader(string sql, CommandType type, OdbcParameter[] pars)
        {
            SqlConnection conn = new SqlConnection(ConnString);
            if (conn.State == ConnectionState.Closed || conn.State == ConnectionState.Broken)
            {
                conn.Open();
            }
            SqlCommand cmd = new SqlCommand(sql, conn);
            if (pars != null && pars.Length > 0)
            {
                foreach (OdbcParameter p in pars)
                {
                    cmd.Parameters.Add(p);
                }
            }
            cmd.CommandType = type;
            SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            return reader;
        } 
        #endregion


        #region 執行一個sql語句，返回一個數據集合DataSet
        /// <summary>
        /// 執行一個sql語句，返回一個數據集合DataSet
        /// </summary>
        /// <param name="sql">select * from tablename...或相關的預存程序</param>
        /// <param name="type">命令類型</param>
        /// <param name="pars">參數集合</param>
        /// <returns>DataSet</returns>
        public static DataSet SelectSqlReturnDataSet(string sql, CommandType type, OdbcParameter[] pars)
        {
            SqlConnection conn = new SqlConnection(ConnString);

            SqlDataAdapter sda = new SqlDataAdapter(sql, conn);

            if (pars != null && pars.Length > 0)
            {
                foreach (OdbcParameter p in pars)
                {
                    sda.SelectCommand.Parameters.Add(p);
                }

            }
            sda.SelectCommand.CommandType = type;
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        } 
        #endregion


        #region SelectSqlReturnDataTable 執行sql語句返回一個數據表DataTable
        /// <summary>
        /// 執行sql語句返回一個數據表DataTable
        /// </summary>
        /// <param name="sql">Select * from ……或相關預存程序</param>
        /// <param name="type">命令類型</param>
        /// <param name="pars">參數集合</param>
        /// <returns>DataTable</returns>
        public static DataTable SelectSqlReturnDataTable(string sql, CommandType type, OdbcParameter[] pars)
        {
            SqlConnection conn = new SqlConnection(ConnString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
            if (pars != null && pars.Length > 0)
            {
                foreach (OdbcParameter p in pars)
                {
                    sda.SelectCommand.Parameters.Add(p);
                }
            }
            sda.SelectCommand.CommandType = type;
            try
            {
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        } 
        #endregion


        #region SelectSqlReturnDataTable 執行sql語句返回數據表DataTable
        /// <summary>
        /// 執行sql語句返回數據表DataTable
        /// </summary>
        /// <param name="sql">select * from ……</param>
        /// <param name="type">text</param>
        /// <returns>DataTable</returns>
        public static DataTable SelectSqlReturnDataTable(string sql, CommandType type)
        {
            SqlConnection conn = new SqlConnection(ConnString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
            sda.SelectCommand.CommandType = type;
            DataTable dt = new DataTable();
            sda.Fill(dt);
            return dt;
        } 
        #endregion

        #region SelectSqlReturnDataTable 執行sql語句返回數據表DataTable
        /// <summary>
        /// 執行sql語句返回數據表DataTable
        /// </summary>
        /// <param name="sql">select * from ……</param>
        /// <param name="type">text</param>
        /// <returns>DataTable</returns>
        public static DataTable SelectSqlReturnDataTable(string sql, CommandType type,string connstring)
        {
            SqlConnection conn = new SqlConnection(connstring);
            SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
            sda.SelectCommand.CommandType = type;
            DataTable dt = new DataTable();
            sda.Fill(dt);
            return dt;
        }
        #endregion
    }
}
