﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObjectWPF.Model;

namespace ObjectWPF.DAL
{
    public class TableService
    {
        //取得table的細節
        public static List<Tables> GetTableDetial(string id)
        {
            string sql = string.Format(@"SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '{0}'", id);
            try
            {
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text);
                List<Tables> tbs = new List<Tables>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Tables t = new Tables();
                    t.欄位序 = dt.Rows[i]["ordinal_position"].ToString();
                    t.欄位名稱 = dt.Rows[i]["column_name"].ToString().TrimStart();
                    t.長度 = dt.Rows[i]["character_maximum_length"].ToString();

                    t.形態 = dt.Rows[i]["data_type"].ToString();
                    t.註解 = "";
                    //t.說明 = "";
                    tbs.Add(t);
                }
                if (tbs.Count == 0)
                {
                    tbs.Add(new Tables
                    {
                        欄位名稱 = "查無資料"
                    }
                        );
                }
                return tbs;
            }
            catch (Exception)
            {
                
                throw;
            }

        }

        public static List<Tables> GetTableIndex(string id)
        {
            string sql = string.Format(@"select distinct o.name, o.type_desc, dep.is_updated
FROM sys.sql_modules   m 
INNER JOIN sys.objects o ON m.object_id=o.object_id
INNER JOIN sys.sql_dependencies dep ON m.object_id = dep.object_id
INNER JOIN sys.columns col ON dep.referenced_major_id = col.object_id
INNER JOIN sys.tables tab ON tab.object_id = col.object_id
WHERE tab.name = '{0}'
ORDER BY O.name", id);
            try
            {
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text);
                List<Tables> tbs = new List<Tables>();
                tbs.Add(new Tables()
                {
                    欄位名稱 = "以下為關聯"
                });
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Tables t = new Tables();
                    t.欄位序 = (i + 1).ToString();
                    t.欄位名稱 = dt.Rows[i]["name"].ToString().TrimStart();
                    //t.長度 = dt.Rows[i]["length"].ToString();
                    //int tmp = dt.Rows[i]["usertype"].ToString().Length == 0 ? -1 : int.Parse(dt.Rows[i]["usertype"].ToString());
                    t.形態 = dt.Rows[i]["type_desc"].ToString();
                    t.註解 = dt.Rows[i]["is_updated"].ToString() == "True" ? "MODIFIED" : "SELECTED";

                   
                    tbs.Add(t);
                }
                if (tbs.Count == 0)
                {
                    tbs.Add(new Tables
                    {
                        欄位名稱 = "查無資料"
                    }
                        );
                }
                return tbs;
            }
            catch (Exception)
            {
                
                throw;
            }

        }
    }
}

