﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObjectWPF.Model;

namespace ObjectWPF.DAL
{
    public class ViewsService
    {
        public static List<Views> GetViewDetial(int id)
        {
            string sql = string.Format(@"select distinct
		        object = s.name + '.' + o.name,
		        type = convert(char(16), v.name)
			        from sysobjects o, master.dbo.spt_values v,
				        sysdepends d, sysusers s
			        where o.id = d.id
				        and o.sysstat & 15 = v.number and v.type = 'O'
			        and d.depid = {0}
			        and o.uid = s.uid", id);
            try
            {
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text);
                List<Views> tbs = new List<Views>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Views t = new Views();
                    t.項次 = i + 1;
                    t.關聯物件 = dt.Rows[i][0].ToString();
                    t.類別 = dt.Rows[i][1].ToString();
                    tbs.Add(t);
                }
                if (tbs.Count == 0)
                {
                    tbs.Add(new Views
                    {
                        關聯物件 = "查無資料"
                    }
                        );
                }
                return tbs;
            }
            catch (Exception)
            {
                
                throw;
            }
        }
    }
}
