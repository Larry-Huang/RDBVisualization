﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObjectWPF.Model;


namespace ObjectWPF.DAL
{
    public class ObjectService
    {
        public static List<Objects> GetObjectTable()
        {
            try
            {
                string sql = @" SELECT sysobjects.name,   
                         sysobjects.id ,
			                pbcattbl.pbt_cmnt 
                   FROM sysobjects,  pbcattbl
	                where sysobjects.type = 'U' and
			                pbcattbl.pbt_tid = sysobjects.id
                order by name";
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text);
                List<Objects> objs = new List<Objects>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Objects obj = new Objects();
                    obj.objectsName = dt.Rows[i][0].ToString().Trim();
                    obj.objectsId = dt.Rows[i][1].ToString();
                    obj.objectmemo = dt.Rows[i][2].ToString();
                    objs.Add(obj);
                }
                return objs;
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        public static List<Objects> GetObjectView()
        {
            try
            {
                string sql = @" SELECT sysobjects.name,   
                                     sysobjects.id  
                                FROM sysobjects  
                               WHERE sysobjects.type = 'V'  
                            order by sysobjects.name
                ";
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text);
                List<Objects> objs = new List<Objects>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Objects obj = new Objects();
                    obj.objectsName = dt.Rows[i][0].ToString();
                    obj.objectsId = dt.Rows[i][1].ToString();
                   // obj.objectmemo = dt.Rows[i][2].ToString();
                    objs.Add(obj);
                }
                return objs;
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        public static List<Objects> GetObjectSP()
        {
            try
            {
                string sql = @" SELECT sysobjects.name,   
                                 sysobjects.id  
                            FROM sysobjects  
                           WHERE sysobjects.type = 'P'  
                        order by sysobjects.name
                ";
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text);
                List<Objects> objs = new List<Objects>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Objects obj = new Objects();
                    obj.objectsName = dt.Rows[i][0].ToString();
                    obj.objectsId = dt.Rows[i][1].ToString();
                   // obj.objectmemo = dt.Rows[i][2].ToString();
                    objs.Add(obj);
                }
                return objs;
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        public static List<string> GetDataBaseName(ConnStringModel connmodle )
        {
            try
            {
                string sql = @"select * from master..sysdatabases";
                string conn =  string.Format("Dsn={0};uid={1};pwd={2}",connmodle.Dsn,connmodle.Uid,connmodle.pwd);
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text, conn);
                List<string> objs = new List<string>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    objs.Add(dt.Rows[i][0].ToString());
                }
                return objs;
            }
            catch (Exception)
            {
                ///沒有權限的帳號回傳:
                return new List<string>() { "npersonel", "pmainforce", "porganization", "npmtp","findiff"};
            }
        }

    }
}
