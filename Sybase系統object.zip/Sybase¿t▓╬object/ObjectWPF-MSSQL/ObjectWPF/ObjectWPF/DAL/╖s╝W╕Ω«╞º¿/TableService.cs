﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObjectWPF.Model;

namespace ObjectWPF.DAL
{
    public class TableService
    {
        public static List<Tables> GetTableDetial(int id)
        {
            string sql = string.Format(@"SELECT 
                     pbcattbl.pbt_cmnt description,   
                     pbcatcol.pbc_cnam names,   
                     pbcatcol.pbc_tnam,   
                     pbcatcol.pbc_hdr,   
                     pbcatcol.pbc_cid id,   
                     syscolumns.length length,   
			         syscolumns.usertype usertype, 
                     pbcatcol.pbc_cmnt memo 
                FROM pbcattbl,   
                     pbcatcol,   
                     syscolumns
               WHERE ( pbcatcol.pbc_tid = pbcattbl.pbt_tid ) 
		            and  ( pbcatcol.pbc_cid = syscolumns.colid ) 
		            and  ( pbcatcol.pbc_tid = syscolumns.id ) 
		            and  ( pbcattbl.pbt_tid = {0} )    
            order by   pbcatcol.pbc_tnam,  pbcatcol.pbc_cid", id);
            try
            {
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text);
                List<Tables> tbs = new List<Tables>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Tables t = new Tables();
                    t.欄位序 = dt.Rows[i]["id"].ToString();
                    t.欄位名稱 = dt.Rows[i]["names"].ToString().TrimStart();
                    t.長度 = dt.Rows[i]["length"].ToString();
                    int tmp = dt.Rows[i]["usertype"].ToString().Length == 0 ? -1 : int.Parse(dt.Rows[i]["usertype"].ToString());
                    t.形態 = Enum.GetName(typeof(Common.USerType), tmp);
                    t.註解 = dt.Rows[i]["memo"].ToString();
                    t.說明 = dt.Rows[i]["description"].ToString();
                    tbs.Add(t);
                }
                if (tbs.Count == 0)
                {
                    tbs.Add(new Tables
                    {
                        欄位名稱 = "查無資料"
                    }
                        );
                }
                return tbs;
            }
            catch (Exception)
            {
                
                throw;
            }

        }

        public static List<Tables> GetTableIndex(int id)
        {
            string sql = string.Format(@"select distinct
		                                object = s.name + '.' + o.name,
		                                type = convert(char(16), v.name)
			                                from sysobjects o, master.dbo.spt_values v,
				                                sysdepends d, sysusers s
			                                where o.id = d.id
				                                and o.sysstat & 15 = v.number 
				                                and v.type = 'O'
				                                and d.depid = {0}
				                                and o.uid = s.uid
                                union all
                                select object =  p.name + '.' + i.name,
		                                type = convert(char(16), 'Index')
			                                from sysindexes i, sysusers p, sysobjects b
			                                where i.id = {0} and 
	   		                                b.id = i.id and
				                                 p.uid = b.uid and
				                                i.indid > 0
                                order by type", id);
            try
            {
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text);
                List<Tables> tbs = new List<Tables>();
                tbs.Add(new Tables()
                {
                    欄位名稱 = "以下為關聯"
                });
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Tables t = new Tables();
                    t.欄位序 = (i + 1).ToString();
                    t.欄位名稱 = dt.Rows[i]["object"].ToString().TrimStart();
                    //t.長度 = dt.Rows[i]["length"].ToString();
                    //int tmp = dt.Rows[i]["usertype"].ToString().Length == 0 ? -1 : int.Parse(dt.Rows[i]["usertype"].ToString());
                    //t.形態 = Enum.GetName(typeof(Common.USerType), tmp);
                    
                    t.註解 = dt.Rows[i]["type"].ToString();
                    tbs.Add(t);
                }
                if (tbs.Count == 0)
                {
                    tbs.Add(new Tables
                    {
                        欄位名稱 = "查無資料"
                    }
                        );
                }
                return tbs;
            }
            catch (Exception)
            {
                
                throw;
            }

        }
    }
}

