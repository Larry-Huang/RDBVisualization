﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObjectWPF.Model;

namespace ObjectWPF.DAL
{
    public class SPService
    {
        public static List<StoreProcedurees> GetSPDetial(int id)
        {
            string sql = string.Format(@"select object = s.name +'.'+ o.name,
		        type = convert(char(16), m0.description),
		        updated = convert(char(10), m1.description)
			        from sysobjects o, master.dbo.spt_values v,
				        sysdepends d, master.dbo.spt_values u,
			        master.dbo.spt_values w,
				        sysusers s, 
				        master.dbo.sysmessages m0, 
				        master.dbo.sysmessages m1
			        where o.id = d.depid
				        and o.sysstat & 15 = v.number and v.type = 'O'
				        and v.msgnum = m0.error
				        and u.type = 'B' and u.number = d.resultobj
				        and u.msgnum = m1.error
				        and w.type = 'B' and w.number = d.readobj
				        and d.id = {0}
				        and o.uid = s.uid", id);
            try
            {
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text);
                List<StoreProcedurees> tbs = new List<StoreProcedurees>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    StoreProcedurees sp = new StoreProcedurees();
                    sp.項次 = i + 1;
                    sp.關聯物件名稱 = dt.Rows[i][0].ToString();
                    sp.類別 = dt.Rows[i][1].ToString();
                    sp.異動權限 = dt.Rows[i][2].ToString();
                    tbs.Add(sp);
                }
                if (tbs.Count == 0)
                {
                    tbs.Add(new StoreProcedurees
                    {
                        關聯物件名稱 = "查無資料"
                    }
                        );
                }
                return tbs;
            }
            catch (Exception)
            {
                
                throw;
            }
        }

    }
}
