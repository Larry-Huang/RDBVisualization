﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObjectWPF.Model;


namespace ObjectWPF.DAL
{
    public class ObjectService
    {
        public static List<Objects> GetObjectTable()
        {
            try
            {
                string sql = @" SELECT 
                        sysobjects.name,   
                        sysobjects.id
                        FROM sysobjects  
                        WHERE sysobjects.type = 'U'  
                        order by sysobjects.name";
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text);
                List<Objects> objs = new List<Objects>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Objects obj = new Objects();
                    obj.objectsName = dt.Rows[i][0].ToString().Trim();
                    obj.objectsId = dt.Rows[i][0].ToString();
                    obj.objectmemo = dt.Rows[i][0].ToString();
                    objs.Add(obj);
                }
                return objs;
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        public static List<Objects> GetObjectView()
        {
            try
            {
                string sql = @" SELECT sysobjects.name,   
                                     sysobjects.id  
                                FROM sysobjects  
                               WHERE sysobjects.type = 'V'  
                            order by sysobjects.name
                ";
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text);
                List<Objects> objs = new List<Objects>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Objects obj = new Objects();
                    obj.objectsName = dt.Rows[i][0].ToString();
                    obj.objectsId = dt.Rows[i][0].ToString();
                   // obj.objectmemo = dt.Rows[i][2].ToString();
                    objs.Add(obj);
                }
                return objs;
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        public static List<Objects> GetObjectSP()
        {
            try
            {
                string sql = @" SELECT sysobjects.name,   
                                 sysobjects.id  
                            FROM sysobjects  
                           WHERE sysobjects.type = 'P'  
                        order by sysobjects.name
                ";
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text);
                List<Objects> objs = new List<Objects>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Objects obj = new Objects();
                    obj.objectsName = dt.Rows[i][0].ToString();
                    obj.objectsId = dt.Rows[i][0].ToString();
                   // obj.objectmemo = dt.Rows[i][2].ToString();
                    objs.Add(obj);
                }
                return objs;
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        public static List<string> GetDataBaseName(string conn )
        {
            try
            {

                string sql = @"select * from master..sysdatabases";
                DataTable dt = SQLhelp.SelectSqlReturnDataTable(sql, CommandType.Text, conn);
                List<string> objs = new List<string>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    objs.Add(dt.Rows[i][0].ToString());
                }
                return objs;
            }
            catch (Exception)
            {
                throw;
                ///沒有權限的帳號回傳:
                //return new List<string>() { "npersonel", "pmainforce", "porganization", "npmtp", "findiff", "personel",
               // "phistory","porg","pretire","rsman","senior","DFJ1","pexchange","pts","sdch1"};
            }
        }

    }
}
