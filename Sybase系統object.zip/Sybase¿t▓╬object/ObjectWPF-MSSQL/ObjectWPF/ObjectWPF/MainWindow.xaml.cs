﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ObjectWPF.DAL;
using ObjectWPF.Model;
using Xceed.Wpf.DataGrid;
using System.Configuration;
using System.Text.RegularExpressions;

namespace ObjectWPF
{
    /// <summary>
    /// MainWindow.xaml 的互動邏輯
    /// </summary>
    public partial class MainWindow : Window
    {
        public string flag = "";

        public string pageName = "";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            GetUsersODBC();
        }

        private void btn_click(object sender, RoutedEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            switch (btn.Name)
            {
                    //登入
                case "btnlogin":                                
                    GetDataBase();                  
                    break;
                    //匯出
                case "btnExport":
                    ExportExcel();
                    break;
                //case "btnsubmit":
                //    LoadObject();
                //    break;
            }
        }

        

        private void datagridView_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                DataGrid dg = e.OriginalSource as DataGrid;
                if (dg.SelectedIndex == -1)
                {
                    return;
                }
                xcdgdataGrid1.Columns.Clear();
                Objects obj = e.AddedItems[0] as Objects;
                pageName = obj.objectsName;
                tbTableNames.Text = obj.objectsName;
                string id = obj.objectsId;
                switch (dg.Name)
                {
                    case "datagridTable":
                        SetDatagrid("datagridTable");
                        //xcdgdataGrid1.ItemsSource = TableService.GetTableDetial(id);
                        List<Tables> tbs = TableService.GetTableDetial(id);
                        tbTableNames.Text += " "+tbs.First().註解;
                        List<Tables> _tbs = TableService.GetTableIndex(id);
                        foreach (var tb in _tbs)
                        {
                            tbs.Add(tb);
                        }
                        xcdgdataGrid1.ItemsSource = tbs;
                        flag = "datagridTable";
                        break;
                    case "datagridView":
                        SetDatagrid("datagridView");
                        xcdgdataGrid1.ItemsSource = ViewsService.GetViewDetial(id);
                        flag = "datagridView";
                        break;
                    case "datagridsp":
                        SetDatagrid("datagridsp");
                        xcdgdataGrid1.ItemsSource = SPService.GetSPDetial(id);
                        flag = "datagridsp";
                        break;
                }
            }
            catch (Exception ex)
            {
                 MessageBox.Show(ex.Message, "錯誤", MessageBoxButton.OK, MessageBoxImage.Information);
                 xcdgdataGrid1.Columns.Clear();
                
            }
        }

        private void cbdatabase_DropDownClosed_1(object sender, EventArgs e)
        {
             ComboBox cb = sender as ComboBox;
             string sel = cb.Text;
             GetObject(sel);
        }
        #region GetUsersODBC
        private void GetUsersODBC()
        {
            //  var odbc = ODBCManager.GetSystemDSNList();
            //var odbcx = ODBCManager.GetUserDSNList();
            List<ComboBoxItem> cbs = new List<ComboBoxItem>();
            ComboBoxItem cb = new ComboBoxItem
            {
                Content = "<-請選擇資料來源->",
                IsSelected = true
            };
            cbs.Add(cb);
            foreach (ConnectionStringSettings conn in System.Configuration.ConfigurationManager.ConnectionStrings)
            {
                ComboBoxItem c = new ComboBoxItem();
                c.Content = conn.Name;
                c.ToolTip =conn.ConnectionString;
                cbs.Add(c);
            }
            //foreach (var o in odbcx)
            //{
            //    ComboBoxItem c = new ComboBoxItem();
            //    c.Content = o.GetDSNName();
            //    cbs.Add(c);
            //}

            cbdsn.ItemsSource = cbs;
            cbdsn.SelectedIndex = 0;
        }
        #endregion

        #region SetDatagrid
        private void SetDatagrid(string Columntypes)
        {

            PropertyInfo[] props = null;
            switch (Columntypes)
            {
                case "datagridTable":
                    props = typeof(Tables).GetProperties();                
                    break;
                case "datagridView":
                    props = typeof(Views).GetProperties();                  
                    break;
                case "datagridsp":
                   props = typeof(StoreProcedurees).GetProperties();                   
                    break;
            }
            foreach (var p in props)
            {
                Column col = new Column();
                col.FieldName = p.Name;
                col.Title = p.Name;
                //col.TextTrimming = TextTrimming.None;
                //col.TextWrapping = TextWrapping.NoWrap;         
                if (p.Name.Equals("說明") || p.Name.Equals("註解") || p.Name.Contains("關聯") || p.Name.Contains("欄位名稱"))
                {
                    col.Width = 250;
                }
                xcdgdataGrid1.Columns.Add(col);
            }
        }
        #endregion

        #region 匯出excel的方法
        /// <summary>
        /// 匯出excel的方法
        /// </summary>
        private void ExportExcel()
        {
            if (xcdgdataGrid1.Columns.Count ==0)
            {
                MessageBox.Show("請先查詢資料", "錯誤", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            try
            {
                Mouse.SetCursor(Cursors.Wait);
                switch (flag)
                {
                    case "datagridTable":
                        List<Tables> tbs = xcdgdataGrid1.ItemsSource as List<Tables>;
                        EXportExcel.DExcelExport<Tables>.FormExcelExport(tbs, pageName);
                        break;
                    case "datagridView":
                        List<Views> vews = xcdgdataGrid1.ItemsSource as List<Views>;
                        EXportExcel.DExcelExport<Views>.FormExcelExport(vews, pageName);
                        break;
                    case "datagridsp":
                        List<StoreProcedurees> sps = xcdgdataGrid1.ItemsSource as List<StoreProcedurees>;
                        EXportExcel.DExcelExport<StoreProcedurees>.FormExcelExport(sps, pageName);
                        break;
                }           
              
            }
            catch (Exception ex)
            {
                MessageBox.Show("檔案匯出失敗，原因"+ex.Message, "錯誤", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                Mouse.SetCursor(Cursors.Arrow);
            }
        }
        #endregion

        #region GetObject
        private void GetObject(string dbname)
        {
            datagridTable.SelectedIndex = -1;
            datagridView.SelectedIndex = -1;
            datagridsp.SelectedIndex = -1;
            //ConnStringModel conn = new ConnStringModel();
            //conn.Dsn = cbdsn.Text;
            //conn.Uid = tbuid.Text;
            //conn.pwd = pbpwd.Password;
            string conn = ((ComboBoxItem)this.cbdsn.SelectedItem).ToolTip.ToString();
            //conn.Database = dbname;
            string temp = conn.Substring(conn.IndexOf("Database="), (conn.IndexOf(";Server") - conn.IndexOf("Database=")));
            string newConn= conn.Replace(temp.Split('=')[1], dbname);
            SQLhelp.conn = newConn;
            //SQLhelp._dbName = dbname;
            try
            {
                datagridTable.ItemsSource = ObjectService.GetObjectTable();
                datagridView.ItemsSource = ObjectService.GetObjectView();
                datagridsp.ItemsSource = ObjectService.GetObjectSP();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "錯誤", MessageBoxButton.OK, MessageBoxImage.Error);

            }
        } 
        #endregion

        #region GetDataBase
        private void GetDataBase()
        {
            List<ComboBoxItem> cbs = new List<ComboBoxItem>();
            string conn = ((ComboBoxItem)this.cbdsn.SelectedItem).ToolTip.ToString();
            List<string> odbcs = ObjectService.GetDataBaseName(conn);
            ComboBoxItem cb = new ComboBoxItem
            {
                Content = "<-請選擇資料庫->",
                IsSelected = true
            };
            cbs.Add(cb);
            foreach (var o in odbcs)
            {
                ComboBoxItem c = new ComboBoxItem();
                c.Content = o;
                cbs.Add(c);
            }
            cbdatabase.ItemsSource = cbs;
            cbdatabase.SelectedIndex = 0;
        } 
        #endregion

       

        
    }
}
