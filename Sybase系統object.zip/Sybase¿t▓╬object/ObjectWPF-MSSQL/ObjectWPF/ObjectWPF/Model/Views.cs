﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectWPF.Model
{
    public class Views
    {

        /// <summary>
        /// 欄位序
        /// </summary>
        public int 項次 { get; set; }
        public string 關聯物件 { get; set; }
        public string 類別 { get; set; }
    }
}
