﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectWPF.Model
{
    public class ConnStringModel
    {
        public string Dsn { get; set; }
        public string Uid { get; set; }
        public string pwd { get; set; }
        public string Database { get; set; }
    }
}
