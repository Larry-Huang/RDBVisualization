﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectWPF.Model
{
    public  class Objects
    {
        /// <summary>
        /// 名稱
        /// </summary>
        public string objectsName { get; set; }
        /// <summary>
        /// ID
        /// </summary>
        public string objectsId { get; set; }
        /// <summary>
        /// 註解
        /// </summary>
        public string objectmemo { get; set; }

    }
}
