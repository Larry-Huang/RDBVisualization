﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectWPF.Model
{
    public class Tables
    {
        /// <summary>
        /// 欄位序
        /// </summary>
        public string 欄位序 { get; set; }
        /// <summary>
        ///名稱
        /// </summary>
        public string 欄位名稱 { get; set; }
        
        /// <summary>
        /// 長度
        /// </summary>
        public string 長度 { get; set; }
        /// <summary>
        /// 型態
        /// </summary>
        public string 形態 { get; set; }
        /// <summary>
        /// 註解
        /// </summary>
        public string 註解 { get; set; }

        /// <summary>
        /// 說明
        /// </summary>
        //public string 說明 { get; set; }
    }
}
