﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectWPF.Model
{
    public   class StoreProcedurees
    {
        // <summary>
        /// 欄位序
        /// </summary>
        public int 項次 { get; set; }
        /// <summary>
        /// 關聯
        /// </summary>
        public string 關聯物件名稱 { get; set; }
        /// <summary>
        /// 類型
        /// </summary>
        public string 類別 { get; set; }
        /// <summary>
        /// 修改權限
        /// </summary>
        public string 異動權限 { get; set; }
    }
}
