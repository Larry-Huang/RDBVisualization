﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using Microsoft.Win32;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Windows.Forms;

namespace ObjectWPF
{
    public class EXportExcel
    {
        public static class DExcelExport<T>
        {
            private static SaveFileDialog dlg = new SaveFileDialog();

            #region 新檔案的路徑給使用者自行選擇
            //新檔案的路徑給使用者自行選擇
            /// <summary>
            /// 檔案的路徑給使用者自行選擇
            /// </summary>
            /// <param name="pageName"></param>
            /// <param name="package"></param>
            private static void DlgSaveAsFile(string pageName, ExcelPackage package)
            {
                dlg.FileName = pageName + DateTime.Now.ToString("yyyyMMdd");
                dlg.DefaultExt = ".xlsx";
                dlg.Filter = "Microsoft Excel 工作表|*.xlsx";
                var dialogResult = dlg.ShowDialog();
                if (dialogResult == DialogResult.OK)
                {
                    package.SaveAs(new FileInfo(dlg.FileName));
                }
            }
            #endregion

            #region Excel表的標題列
            /// <summary>
            /// Excel表的標題列
            /// </summary>
            /// <returns></returns>
            private static List<string> CreateHeader(string pageName)
            {
                PropertyInfo[] headerInfo = typeof(T).GetProperties();

                // Create an array for the headers and add it to the
                // worksheet starting at cell A1.
                List<string> objHeaders = new List<string>();
                //修改成foreach
                foreach (var hfo in headerInfo)
                {
                    objHeaders.Add(hfo.Name);
                }
                return objHeaders;
            }
            #endregion


            #region 輸出EXCEL的通用方法
            /// <summary>
            /// 此方法輸出為格式化樣式(如果沒有特殊需求均採用此樣式)
            /// </summary>
            /// <param name="fcollection"></param>
            /// <param name="pageName"></param>
            /// <returns></returns>
            public static string FormExcelExport(IList<T> fcollection, string pageName)
            {
                List<string> obj = CreateHeader(pageName);
                DirectoryInfo inputDir = new DirectoryInfo(@"Content");
               // FileInfo tmpFile = new FileInfo(inputDir.FullName + @"\D.xlsx");
                FileInfo newFile = new FileInfo(inputDir.FullName + pageName + DateTime.Now.ToString("yyyyMMdd") + ".xlsx");

                if (newFile.Exists)
                {
                    newFile.Delete();
                    newFile = new FileInfo(inputDir.FullName + pageName + DateTime.Now.ToString("yyyyMMdd") + ".xlsx");
                }
                using (ExcelPackage package = new ExcelPackage(newFile))
                {
                    //worksheet 1 工作表1
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(pageName);

                    worksheet.DefaultColWidth = 10;
                    worksheet.DefaultRowHeight = 25;
                    //設定標題
                    PropertyInfo[] header = typeof(T).GetProperties();
                    var range = worksheet.Cells[1, 1, 1, header.Count()];
                    range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    range.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                    range.Style.Font.Bold = true;
                    range.Merge = true;
                    range.Value = pageName;

                    //載入資料
                    var dataRange = worksheet.Cells["A2"].LoadFromCollection(
                       fcollection,
                       true, OfficeOpenXml.Table.TableStyles.Light16);

                    dataRange.AutoFitColumns();
                    dataRange.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                    DlgSaveAsFile(pageName, package);

                }
                return newFile.FullName;
            }
            #endregion

        }
    }
}
