﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectWPF
{
    public class Common
    {
       public enum USerType
        {
            ExtendedType=-1,
            Char=1,
            Varchar=2,
            Binary=3,
            Varbinary=4,
            Tinyint=5,
            Smallint=6,
            Int=7,
            Floats=8,
            Numeric=10,
            Money=11,
            Datetime=12,
            Intn=13,
            Floatn=14,
            Datetimn=15,
            Bit=16,
            Moneyn=17,
            Sysname=18,
            Text=19,
            Image=20,
            Smallmoney=21,
            Smalldatetime=22,
            Real=23,
            Nchar=24,
            Nvarchar=25,
            Decimals= 26	,
            Decimaln= 27,
            Numericn=28,
            Unichar=34,
            Univarchar=35,
            Date=37,
            Time=38,
            Daten=39,
            Timen=40,
            Timestamp=80

        }
    }
}
